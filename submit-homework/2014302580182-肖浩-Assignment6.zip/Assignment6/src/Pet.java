import java.util.Set;

public class Pet {
	private int id;
	private String name;
	private String eat;
	private String drink;
	private String live;
	private Set<String> hobby;
	
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEat() {
		return eat;
	}
	public void setEat(String eat) {
		this.eat = eat;
	}
	public String getDrink() {
		return drink;
	}
	public void setDrink(String drink) {
		this.drink = drink;
	}
	public String getLive() {
		return live;
	}
	public void setLive(String live) {
		this.live = live;
	}
	public Set<String> getHobby() {
		return hobby;
	}
	public void setHobby(Set<String> hobby) {
		this.hobby = hobby;
	}
	/*public Set<Comment> getComments() {
		return comments;
	}
	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}*/
	
}
