import javax.swing.JFrame;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.widgets.Label;



public class PetShop extends Shell {

	/**
	 * Launch the application.
	 * @param args
	 */
	static Text text;
	
	public static void main(String args[]) {
		try {
			Display display = Display.getDefault();
			PetShop shell = new PetShop(display);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell.
	 * @param display
	 */
	public PetShop(final Display display) {
		super(display, SWT.SHELL_TRIM);
		final Shell shell = new Shell(display);
		final JFrame frame = new JFrame();
		Button btnNewButton = new Button(this, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 20, SWT.BOLD | SWT.ITALIC));
		
		btnNewButton.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		btnNewButton.setBounds(42, 21, 340, 101);
		btnNewButton.setText("Welcome To Pet Shop");
		
		Button btnNewButton_1 = new Button(this, SWT.NONE);
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
				
				//创建新的窗口
				Shell shell = new Shell(display);
				shell.setLayout(null);
				Text cat=new Text(shell,SWT.MULTI); //声明一个可以显示多行信息的文本框
				shell.setText("Cat"); //设置主窗体的标题
				shell.setSize(450,500); //设置主窗体的大小
				Color color=new Color(Display.getCurrent(),255,255,255);//声明颜色对象
				shell.setBackground(color); //设置窗体的背景颜色
				cat.setText("\n\n宠物猫：天资聪颖，温文尔雅，反应灵敏，善解人意。"
						+ "\n\n性情：属外静内动，表面安静懒动，却隐匿了内心的喜怒哀乐，而且渴望得到主人\n的关爱。集宠物的优秀性情于一身，举止高雅，恬静可爱"
						+ "\n\n单价：30￥");//设置文本框信息
				cat.pack(); //自动调整文本框的大小
				
				shell.open(); //打开主窗体
			}

			
			});
		btnNewButton_1.setBounds(42, 193, 80, 27);
		btnNewButton_1.setText("cats");
		
		
		Button btnNewButton_2 = new Button(this, SWT.NONE);
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
				Shell shell = new Shell(display);
				shell.setLayout(null);
				Text dog=new Text(shell,SWT.MULTI); 
				shell.setText("Dog"); 
				shell.setSize(450,500); 
				Color color=new Color(Display.getCurrent(),255,255,255);
				shell.setBackground(color); 
				dog.setText("\n\n宠物狗：天资聪颖，温文尔雅，忠心不二。"
						+ "\n\n性情：乖巧 幽默 可爱 忠诚"
						+ "\n\n单价：40￥");
				dog.pack(); 
				
				shell.open(); 
			}

		});
		btnNewButton_2.setBounds(302, 193, 80, 27);
		btnNewButton_2.setText("dogs");
		
		Button btnNewButton_3 = new Button(this, SWT.NONE);
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
				Shell shell = new Shell(display);
				shell.setLayout(null);
				Text hamster=new Text(shell,SWT.MULTI);
				shell.setText("hamster");
				shell.setSize(450,500); 
				Color color=new Color(Display.getCurrent(),255,255,255);
				shell.setBackground(color); 
				hamster.setText("\n\n仓鼠：小巧玲珑，乖巧可爱"
						+ "\n\n性情：乖巧  可爱  可以培养主人爱心 陶冶情操"
						+ "\n\n单价：20￥");
				hamster.pack(); 
				
				shell.open(); 
			}

			
		});
		btnNewButton_3.setBounds(42, 331, 80, 27);
		btnNewButton_3.setText("hamster");
		
		Button btnNewButton_4 = new Button(this, SWT.NONE);
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				
				Shell shell = new Shell(display);
				shell.setLayout(null);
				Text parrot=new Text(shell,SWT.MULTI);
				shell.setText("parrot"); 
				shell.setSize(450,500); 
				Color color=new Color(Display.getCurrent(),255,255,255);
				shell.setBackground(color); 
				parrot.setText("\n\n鹦鹉：美观 可爱 幽默 学习能力极强。"
						+ "\n\n习性：主食植物果实、种子、坚果、浆果、嫩芽嫩枝等"
						+ "\n\n单价：25￥");
				parrot.pack(); 
				
				shell.open();
				
				
				
			       
			}
		});
		btnNewButton_4.setBounds(302, 331, 80, 27);
		btnNewButton_4.setText("parrot");
		createContents();
	}

	/**
	 * Create contents of the shell.
	 */
	protected void createContents() {
		setText("SWT Application");
		setSize(450, 500);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
